//функция, которая производит отправку голоса на сервер
async function doVote(event) {
    try {
        await fetch(
            // выбираем из дата-атрибута эелемнта, сгенерировавшего событие, нужное жувотное
            `https://sf-pyw.mosyag.in/sse/vote/${event.target.dataset.pet}`,
            {
                method: 'POST',

            }
        );
        //переадресация на страницу результатов голосования
        window.location.replace('./pages/vote_results.html');
    } catch( e ) {
        console.error('Ошибка: ', e );
        alert( 'Возникла ошибка при передаче голоса на сервер. Попробуйте ещё раз.' );
    }
}
//вешаем обработчики события клика на кнопки, само животное прописано в дата атрибуте кнопки
document.querySelectorAll('.btn-vote').forEach( btn => btn.addEventListener('click', doVote) );