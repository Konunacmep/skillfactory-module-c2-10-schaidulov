//выбираем все прогрессбары, они нам понядобятся дважды
const progress = document.querySelectorAll('.vote-bar');
//создаем объект EventSourse
const ES = new EventSource('https://sf-pyw.mosyag.in/sse/vote/stats');
//обработка ошибки, просто выведем сообщение об этом в сами прогрессбары
ES.onerror = error => {
    if (ES.readyState) {
        progress.forEach(progr => progr.textContent = "Some error");
    } else {null;}
    console.log( error );
};
//обработка входных данных
ES.onmessage = message => {
    //данные - строка, поэтому превращаем в объект
    let jmessage = JSON.parse(message.data);
    //ищем за кого больше всего голосов, будем его брать за 100%
    let bigValue = Math.max(jmessage.cats, jmessage.dogs, jmessage.parrots);
    //теперь считаем заполнение прогресс баров, максимальный -100%, остальные считаются в зависимости от него
    //соответственно меняем размер прогрессбара и количество голосов в textContent в нем
    progress.forEach( progr => {
        let thisPet = progr.dataset.pet;
        if (jmessage[thisPet] === bigValue) {
            progr.style.cssText = `width: ${100}%;`;
        } else {
            progr.style.cssText = `width: ${jmessage[thisPet] / bigValue * 100}%;`;
        }
        progr.textContent = `${jmessage[thisPet]} голосов`;
    });
};
